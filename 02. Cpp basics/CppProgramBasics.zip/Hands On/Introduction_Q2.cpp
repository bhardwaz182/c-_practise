#include<iostream>
using namespace std;

int main(){
     cout<< "Enter 3 numbers\n";
     int a,b,c;
     cin>>   a >> b >> c;
     cout << "a:" << a << endl;
     cout << "b:" << b << endl;
     cout << "c:" << c;
     return 0;
}
