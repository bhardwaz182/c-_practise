#include<iostream>
using namespace std;

int main()
{
	float a,b,c,d,e;
	cin >> a >> b >> c >> d >> e;
	cout << "a:" << a << endl;
	cout << "b:" << b << endl;
	cout << "c:" << c << endl;
	cout << "d:" << d << endl;
	cout << "e:" << e << endl;
	return 0;
}

