#include<iostream>
using namespace std;
main()
{
	int a,b;
	cin >> a >> b;
	cout << "sum:" << a+b << endl;
	cout << "Difference:" << a-b;
}
