#include<iostream>
using namespace std;
int main()
{
	int n;
	cin >> n;
	cout << "No of 10 rupe notes required is " << n/10 << endl;
	cout << "No of 50 rupe notes required is " << n/50 << endl;
	cout << "No of 100 rupe notes required is " << n/100;
}
