#include<iostream>
using namespace std;
main()
{
	int a;
	string b;
	cin >> a;
	b = (a > 10) ? "is greater than 10" : "is less than 10";
	cout << b;
}
