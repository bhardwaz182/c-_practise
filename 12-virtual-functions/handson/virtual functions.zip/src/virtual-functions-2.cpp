//veichles--fourwheelers--cars---sedan,suv

#include<iostream>
using namespace std;

