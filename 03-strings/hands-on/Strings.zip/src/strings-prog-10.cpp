#include<iostream>
using namespace std;
int main(int argv,char* argc[]){
    cout<<argc[1];
    return 0;
}